# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

"""This file will be removed soon in favor of azureml._common."""
# flake8: noqa

from azureml._common.async_utils.task_queue import TaskQueue
